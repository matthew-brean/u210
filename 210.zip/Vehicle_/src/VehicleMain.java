import java.util.Scanner;
public class VehicleMain {
	public static void main(String[] args) {
		
		Scanner SCAN= new Scanner(System.in);
		System.out.println("Increase speed (to accelerate): ");
		int accel = SCAN.nextInt();		
		System.out.println("Decrease speed (to brake): ");
		int brake = SCAN.nextInt();
		System.out.println("Colour: ");
		String colour = SCAN.nextLine();
		System.out.println("# Doors: ");
		int doors = SCAN.nextInt();
		System.out.println("License plate: ");
		String licensePlate = SCAN.nextLine();
		//numtSystem.out
		
		
		System.out.println();//blank line
		Truck class1 = new Truck();
		int numTruckTires = class1.numTires();
		System.out.println("# of Truck tires: "+numTruckTires);
		
		Bike class2 = new Bike();
		int numBikeTires = class2.numTires();
		System.out.println("# of Bike tires: "+numBikeTires);
		
		//System.out.println("# Doors: ");
		//Bike object = new Bike(); //creating object
		//Truck object2 = new Truck(); //creating object
		
	}




}
